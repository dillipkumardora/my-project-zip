package com.niit.webapp.model;

import java.util.List;

public class FriendModel {
	
	private List<User> usersToBefriend;

	public List<User> getUsersToBefriend() {
		return usersToBefriend;
	}

	public void setUsersToBefriend(List<User> usersToBefriend) {
		this.usersToBefriend = usersToBefriend;
	}
	
	
	
}
