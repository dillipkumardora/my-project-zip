var codehub = angular.module('codehub', [
    'ngRoute', 
    'authenticationModule',
    'blogModule',
    'textAngular',
    'forumModule',
    'userModule',
    'jobModule',
    'eventModule',
    'blogCommentModule',
    'adminModule',
    'requestModule',
    'friendModule',
    'chatModule',
    'textAngular'
    ]);
